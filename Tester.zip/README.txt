For copying and licensing issues, see LICENSE.txt.

The tests in this archive require JUnit.

JUnit installation
Eclipse
download JUnit tools : https://marketplace.eclipse.org/content/junit-tools
Open eclipse, click Project -> properties -> Java Build Path -> Classpath -> Add Library -> JUnit, pick JUnit 5
You can run the test normally now
IntelliJ
IntelliJ: https://www.jetbrains.com/help/idea/testing.html
See: Add testing libraries if there's a problem with importing.

VSCode
VSCode: https://youtu.be/LRkqvZs857c?t=176